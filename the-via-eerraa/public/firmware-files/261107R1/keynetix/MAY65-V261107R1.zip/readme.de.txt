======================================================================
H7S Firmware Guide
======================================================================

■ Vorbereitung und Hinweise

- Verwenden Sie die zur Tastatur passende Release-ZIP.
- Prüfen und sichern Sie vor dem Update Ihre Einstellungen gemäß der Anleitung unter https://usekb.cc.
- Reguläre .uf2: Für reguläre Firmware-Updates; behält kompatible gültige Einstellungen bei.
- Reset.uf2: Vollständige Tastatur-Firmware, die bei jeder erfolgreichen Installation einmalig alle gespeicherten Einstellungen zurücksetzt. Spätere Neustarts behalten die Einstellungen bei, und eine erneute Installation derselben Datei setzt sie wieder zurück. Die reguläre Firmware muss danach nicht erneut installiert werden. Ein Abbruch während Übertragung oder Aktivierung gilt nicht als erfolgreiche Installation.

■ Firmware-Installation

1. Wechseln Sie über eine der folgenden Methoden in den Bootloader-Modus.
   - Einstellungsansicht: SYSTEM -> BOOT -> Jump To BOOT
   - Taste QK_BOOT in der Tastenbelegung
   - USB anschließen, während die Taste oben links gedrückt gehalten wird
2. Sobald der Wechseldatenträger des Bootloaders erscheint, kopieren Sie die zum Zweck passende Datei .uf2.
   (Reguläres Update: reguläre .uf2 / Einstellungen zurücksetzen: Reset.uf2)
3. Nach Abschluss des Kopiervorgangs startet die Tastatur automatisch neu.

■ Tastatureinstellungen

- Nutzen Sie für Tastatureinstellungen und Funktionshinweise https://usekb.cc sowie Help neben dem jeweiligen Menü.
- Hinweise zur Verwendung des offiziellen VIA (https://usevia.app) finden Sie in usevia.app/usevia.txt innerhalb der Release-ZIP.
