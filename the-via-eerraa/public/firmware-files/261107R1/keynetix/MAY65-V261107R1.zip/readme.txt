======================================================================
H7S Firmware Guide
======================================================================

----------------------------------------------------------------------
한국어
----------------------------------------------------------------------

■ 준비 및 주의사항

- 사용 중인 키보드에 맞는 배포 ZIP을 사용하십시오.
- 업데이트 전에 https://usekb.cc 의 안내에 따라 설정을 확인하고 백업하십시오.
- 일반 .uf2: 일반 펌웨어 업데이트용이며 호환되는 유효한 설정을 유지합니다.
- Reset.uf2: 전체 키보드 펌웨어이며 성공적인 설치마다 한 번 모든 저장 설정을 초기화합니다. 이후 재부팅은 설정을 유지하고 같은 파일을 다시 설치하면 다시 초기화합니다. 일반 펌웨어를 다시 설치할 필요가 없습니다. 전송·활성화 중단은 성공적인 설치가 아닙니다.

■ 펌웨어 설치

1. 다음 방법 중 하나로 Bootloader 모드에 진입합니다.
   - 설정 화면: SYSTEM -> BOOT -> Jump To BOOT
   - 키맵의 QK_BOOT 키
   - 왼쪽 위 키를 누른 채 USB 연결
2. 부트로더 이동식 디스크가 나타나면 목적에 맞는 .uf2 파일을 복사합니다.
   (일반 업데이트: 일반 .uf2 / 설정 초기화: Reset.uf2)
3. 복사가 끝나면 키보드가 자동으로 재시작합니다.

■ 키보드 설정

- 키보드 설정과 기능별 안내는 https://usekb.cc 및 각 메뉴 옆 Help를 이용하십시오.
- 공식 VIA(https://usevia.app) 사용법은 배포 ZIP의 usevia.app/usevia.txt를 참고하십시오.

----------------------------------------------------------------------
English
----------------------------------------------------------------------

■ Preparation and Precautions

- Use the release ZIP that matches your keyboard.
- Check and back up your settings before updating by following the guide at https://usekb.cc.
- Standard .uf2: For standard firmware updates; preserves compatible valid settings.
- Reset.uf2: Full keyboard firmware that resets all saved settings once per successful installation. Subsequent reboots keep saved settings, and reinstalling the same file resets them again. There is no need to reinstall standard firmware afterward. An interrupted transfer or activation is not a successful installation.

■ Firmware Installation

1. Enter Bootloader mode using one of the following methods.
   - Settings screen: SYSTEM -> BOOT -> Jump To BOOT
   - QK_BOOT key on the keymap
   - Connect USB while holding the top-left key
2. When the bootloader removable disk appears, copy the appropriate .uf2 file.
   (Standard update: standard .uf2 / Settings reset: Reset.uf2)
3. When copying finishes, the keyboard restarts automatically.

■ Keyboard Configuration

- For keyboard configuration and per-feature guides, use https://usekb.cc and Help next to each menu.
- For official VIA (https://usevia.app) instructions, see usevia.app/usevia.txt in the release ZIP.
