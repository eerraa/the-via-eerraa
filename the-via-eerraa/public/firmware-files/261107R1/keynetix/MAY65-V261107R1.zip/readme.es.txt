======================================================================
H7S Firmware Guide
======================================================================

■ Preparación y precauciones

- Utilice el ZIP de distribución correspondiente a su teclado.
- Antes de actualizar, compruebe sus ajustes y haga una copia de seguridad siguiendo las instrucciones de https://usekb.cc.
- .uf2 estándar: sirve para actualizaciones estándar de firmware y conserva los ajustes válidos compatibles.
- Reset.uf2: es un firmware completo del teclado y restablece una vez todos los ajustes guardados tras cada instalación exitosa. Los reinicios posteriores conservan los ajustes, y volver a instalar el mismo archivo los restablece de nuevo. No es necesario volver a instalar el firmware estándar. Una transferencia o activación interrumpida no es una instalación exitosa.

■ Instalación del firmware

1. Entre en el modo Bootloader mediante uno de los siguientes métodos.
   - Pantalla de ajustes: SYSTEM -> BOOT -> Jump To BOOT
   - Tecla QK_BOOT en el mapa de teclas
   - Conectar el USB manteniendo pulsada la tecla superior izquierda
2. Cuando aparezca el disco extraíble del bootloader, copie el archivo .uf2 adecuado para su propósito.
   (Actualización estándar: .uf2 estándar / Restablecimiento de ajustes: Reset.uf2)
3. Al terminar la copia, el teclado se reiniciará automáticamente.

■ Configuración del teclado

- Para la configuración del teclado y la guía por funciones, utilice https://usekb.cc y el botón Help junto a cada menú.
- Para el uso de VIA oficial (https://usevia.app), consulte usevia.app/usevia.txt en el ZIP de distribución.
