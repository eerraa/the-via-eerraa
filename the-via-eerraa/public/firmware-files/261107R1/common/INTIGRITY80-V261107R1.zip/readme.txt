======================================================================
H7S Firmware Guide
======================================================================

----------------------------------------------------------------------
한국어
----------------------------------------------------------------------

■ 준비 및 주의사항

- 키보드의 메이커와 보드 이름이 모두 일치하는 배포 ZIP을 사용하십시오.
- 업데이트 전에 https://usekb.cc 의 안내에 따라 설정을 확인하고 백업하십시오.
- 일반 .uf2: 일반 펌웨어 업데이트용이며 호환되는 유효한 설정을 유지합니다.
- Reset.uf2: 전체 키보드 펌웨어이며 성공적인 설치마다 한 번 모든 저장 설정을
  초기화합니다. 이후 재부팅은 설정을 유지하고 같은 파일을 다시 설치하면 다시
  초기화합니다. 일반 펌웨어를 다시 설치할 필요가 없습니다.
  전송·활성화 중단은 성공적인 설치가 아닙니다.

■ 펌웨어 설치

1. 다음 방법 중 하나로 Bootloader 모드에 진입합니다.
   - 설정 화면의 SYSTEM -> BOOT -> Jump To BOOT
   - 키맵의 QK_BOOT 키
   - 왼쪽 위 키를 누른 채 USB 연결
2. 부트로더 이동식 디스크가 나타나면 목적에 맞는 .uf2 파일을 복사합니다.
   (일반 업데이트: 일반 .uf2 / 설정 초기화: Reset.uf2)
3. 복사가 끝나면 키보드가 자동으로 재시작합니다.

■ 키보드 설정

- 키보드 설정과 기능별 안내는 https://usekb.cc 및 각 메뉴 옆 Help를 이용하십시오.
- 공식 VIA(https://usevia.app) 사용법은 배포 ZIP의 usevia.app/usevia.txt를
  참고하십시오.


----------------------------------------------------------------------
English
----------------------------------------------------------------------

■ Preparation and Warnings

- Use the release ZIP that matches both your keyboard's maker and board name.
- Before updating, check and back up your settings following the guidance at
  https://usekb.cc.
- Normal .uf2: use this for ordinary updates; valid compatible settings remain.
- Reset.uf2: full keyboard firmware that clears all saved settings once per
  successful installation. Later boots preserve settings; reinstalling the same
  file resets them again. No normal-firmware reflash is needed.
  Interrupted upload/activation is not a successful installation.

■ Firmware Installation

1. Enter Bootloader mode using one of these methods:
   - SYSTEM -> BOOT -> Jump To BOOT in the configuration UI
   - QK_BOOT in your keymap
   - Hold the top-left key while plugging in USB
2. When the bootloader removable drive appears, copy the intended .uf2 file
   (normal .uf2 for an update, or Reset.uf2 to reset settings).
3. The keyboard restarts automatically after copying finishes.

■ Keyboard Configuration

- Use https://usekb.cc and the Help beside each menu for configuration and
  feature details.
- For official VIA (https://usevia.app), see usevia.app/usevia.txt in the
  release ZIP.
